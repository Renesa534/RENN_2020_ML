const express = require("express");
const app = express()
//require("./db/conn");
const path = require("path")
//const Student = require("./module/contact");
//const app = express();
//app.use(express.json());
const port = process.env.PORT || 80;

console.log(path.join(__dirname, "../../vuume"));
const rohan = path.join(__dirname, "../../vuume");
app.use(express.static(rohan));

//const static_path = path.join(__dirname,"../vuume");
//app.use(express.static(static_path))
//app.set("view engine","hbs")

app.get("/",(req,res)=>{
    res.render("index");
})

//app.get("/contact",(req,res)=>{
  ///  res.send("RADHE RADHE");
//    res.render("contact");
//})

//app.post("/contact",(req,res)=>{
  //  console.log(req.body);
   // res.render("contact");
  //  const user = new Student(req.body)
  //  user.save().then(()=>{
  //      res.status(201).send(user)   
   // }).catch((err) => {
     //   res.status(400).send(err)
  // });
//})

app.listen(port,()=>{
    console.log(`Connection Successful at ${port}`);
})