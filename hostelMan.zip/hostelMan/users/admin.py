from django.contrib import admin
from .models import Profile, Hostelpreferences, HLeave, Student

admin.site.register(Profile)
admin.site.register(Hostelpreferences)
admin.site.register(HLeave)
admin.site.register(Student)

