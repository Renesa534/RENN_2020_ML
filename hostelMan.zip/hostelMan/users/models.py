from django.db import models
from django.contrib.auth.models import User

class Student(models.Model):
    student_name = models.CharField(max_length=100)
    guardian_name = models.CharField(max_length=100)
    email_id = models.EmailField()
    enroll_no = models.CharField(max_length=20)
    DOB = models.DateField()
    gender = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    contact_no = models.CharField(max_length=15)
    parents_no = models.CharField(max_length=15)
    blood_group = models.CharField(max_length=10)
    def __str__(self):
        return self.student_name  

class Profile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    image = models.ImageField(default='default.jpg',upload_to='profile_pics')
    student_name = models.CharField(max_length=100)
    guardian_name = models.CharField(max_length=100)
    email_id = models.EmailField()
    DOB = models.DateField()
    gender = models.CharField(max_length=20)
    address = models.CharField(max_length=100)
    contact_no = models.CharField(max_length=15)
    parents_no = models.CharField(max_length=15)
    blood_group = models.CharField(max_length=10)
    def __str__(self):
        return f'{self.user.username}Profile'

class Hostelpreferences(models.Model):
    student_name = models.CharField(max_length=100)
    room_type = models.CharField(max_length=100)
    def __str__(self):
        return self.enroll_no

class HLeave(models.Model): 
    from_date = models.DateField()
    to_date = models.DateField()
    hostel_name = models.CharField(max_length=100)
    student_name = models.CharField(max_length=100)
    room_no = models.CharField(max_length=100)
    reason = models.TextField()
       


# Create your models here.


