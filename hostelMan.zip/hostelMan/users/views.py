from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegisterForm
from .models import Hostelpreferences
from .models import HLeave
from .models import Student
from django.contrib.auth.models import User

def register(request):
    if request.method == 'POST':
        #
        #student = Student(student_name=textname,guardian_name=guardianname,enroll_no=en_no,address=personaladdress,gender=sex,email_id=emailid,DOB=dob,contact_no=mobileno,parents_no=parentsno,blood_group=blood)
        #student.save()
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request,f'Your account has been created.You are now able to login')
            return redirect('login')   
    else:
        form = UserRegisterForm()    
    return render(request,'users/register.html',{'form':form})
def login(request):
    return render(request,'users/st_login.html')    
def logout(request):
    return render(request,'users/logout.html')
     
def choice(request):
    return render(request,'users/stud_choice.html') 
@login_required      
def profile(request):
    return render(request,'users/profile.html')
def hostel_pre(request):
    return render(request,'users/hostel_pref.html') 
def std1(request):
    textname = request.POST["textname"]
    rt = request.POST["rt"]
    hostel_preferences = Hostelpreferences(student_name=textname,room_type=rt)
    hostel_preferences.save()
    messages.info(request, 'Successfully submitted')
    return redirect('/choice')
def hleave(request):
    return render(request,'users/application.html') 
def std2(request):
    start_date = request.POST["start_date"]
    finish_date = request.POST["finish_date"]
    name = request.POST["name"]
    hname = request.POST["hname"]
    room = request.POST["room"]
    reason = request.POST["reason"]
    hleave = HLeave(from_date=start_date,to_date=finish_date,hostel_name=hname,student_name=name,room_no=room,reason=reason)
    hleave.save()
    messages.info(request, 'Successfully submitted')
    return redirect('/choice')    




