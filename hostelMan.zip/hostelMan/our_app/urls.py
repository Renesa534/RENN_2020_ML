from django.urls import path
from . import views

urlpatterns = [
    path('',views.hi, name='home-page'),
    path('fees/',views.fees, name='fee-page'),
    path('about/',views.about, name='about-page'),
    path('details/',views.details, name='hostel-page'),


]
