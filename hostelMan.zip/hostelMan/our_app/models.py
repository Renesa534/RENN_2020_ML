from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class FSabana(models.Model):
    room_no = models.CharField(max_length=100)
    bt = models.CharField(max_length=100)
    available = models.CharField(max_length=100)

class FRetro(models.Model):
    room_no = models.CharField(max_length=100)
    bt = models.CharField(max_length=100)
    available = models.CharField(max_length=100)

class MHeuristic(models.Model):
    room_no = models.CharField(max_length=100)
    bt = models.CharField(max_length=100)
    available = models.CharField(max_length=100)

class MGalaxy(models.Model):
    room_no = models.CharField(max_length=100)
    bt = models.CharField(max_length=100)
    available = models.CharField(max_length=100)

class Enrollno(models.Model):
    #Number = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    Number = models.CharField(max_length=15)

class FeeDetails(models.Model):
    sabana = models.CharField(max_length=100)
    retro = models.CharField(max_length=100)
    heuristic = models.CharField(max_length=100)
    galaxy = models.CharField(max_length=100)
        




class Hostels(models.Model):
    enroll_no = models.CharField(max_length=20)
    hostel_name = models.CharField(max_length=100)
    room_no = models.CharField(max_length=100)
    
        
    

    
