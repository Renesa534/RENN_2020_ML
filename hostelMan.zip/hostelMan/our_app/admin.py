from django.contrib import admin
from .models import FSabana, Enrollno, FeeDetails, FRetro, MHeuristic, MGalaxy, Hostels
# Register your models here.



admin.site.register(FSabana)
admin.site.register(FRetro)
admin.site.register(MHeuristic)
admin.site.register(MGalaxy)
admin.site.register(Enrollno)
admin.site.register(FeeDetails)
admin.site.register(Hostels)


