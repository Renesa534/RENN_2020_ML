from django.apps import AppConfig


class OurAppConfig(AppConfig):
    name = 'our_app'
