from django.shortcuts import render
from .models import FeeDetails
from .models import Hostels
# Create your views here.

def hi(request):
    return render(request, 'our_app/homepage.html')
def fees(request):
    context = {
       'fees' : FeeDetails.objects.all()
    }
    return render(request, 'our_app/fees.html',context) 
def about(request):
    return render(request, 'our_app/about.html')
def details(request):
    context = {
       'details' : Hostels.objects.all()
    }
    return render(request, 'our_app/room_det.html',context)        




