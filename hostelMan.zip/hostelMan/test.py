abhay ={
    "age":20,
    "roll": 832904
}
verma = 80
search = {
    'abhay': abhay,
    "verma": verma,
}

print(search["abhay"])

new = input("regitser: ")

list = {f"{i}": i} for i in stulist