from django.contrib import admin
from .models import Bookartist

admin.site.register(Bookartist)



# Register your models here.
