from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegisterForm
from .models import Bookartist
from django.contrib.auth.models import User

# Create your views here.

def hi(request):
    return render(request, 'home/index.html')
def register(request):
    if request.method == 'POST':
        #
        #student = Student(student_name=textname,guardian_name=guardianname,enroll_no=en_no,address=personaladdress,gender=sex,email_id=emailid,DOB=dob,contact_no=mobileno,parents_no=parentsno,blood_group=blood)
        #student.save()
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request,f'Your account has been created.You are now able to login')
            return redirect('login')   
    else:
        form = UserRegisterForm()    
    return render(request,'home/register.html',{'form':form}) 

def login(request):
    return render(request,'home/login.html')    
def logout(request):
    return render(request,'home/logout.html')
@login_required
def bookingartist(request):
    return render(request, 'home/booking.html')
def std(request):
    sector = request.POST["sector"]
    artist_no = request.POST["artist_no"]
    date_of_event = request.POST["date_of_event"]
    time_of_event = request.POST["time_of_event"]
    music_type = request.POST["music_type"]
    budget_of_event = request.POST["budget_of_event"]
    venue_of_event = request.POST["venue_of_event"]
    comment = request.POST["comment"]
    first = request.POST["first"]
    last = request.POST["last"]
    contact_no = request.POST["contact_no"]
    email = request.POST["email"]
    bookartist = Bookartist(categories=sector,no_of_artist=artist_no,Event_date=date_of_event,Event_time=time_of_event,type_of_music=music_type,budget=budget_of_event,venue=venue_of_event,message=comment,first_name=first,last_name=last,phone_no=contact_no,email_id=email)
    bookartist.save()
    messages.info(request, 'Successfully submitted')
    return redirect('/bookingartist') 

