from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Bookartist(models.Model):
    categories = models.CharField(max_length=100)
    no_of_artist = models.CharField(max_length=50)
    Event_date = models.DateField()
    Event_time = models.TimeField()
    type_of_music= models.CharField(max_length=100)
    budget= models.CharField(max_length=15)
    venue= models.CharField(max_length=100)
    message = models.TextField()
    first_name= models.CharField(max_length=100)
    last_name= models.CharField(max_length=100)
    phone_no= models.CharField(max_length=15)
    email_id = models.EmailField()
    class Meta:
        db_table= "bookartist"
       
